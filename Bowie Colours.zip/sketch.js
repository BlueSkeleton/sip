let pic;
function preload(){
 pic = loadImage("Bowie.jpg") 
}
function setup() { 
  createCanvas(700, 700);
  noStroke();
}
function draw() { 
  background(0);
  pic.loadPixels();
  let r = (random(-100,100))
  let ra = (random(-100,100))
  let ran = (random(-100,100))
  let stepSize = 1;
  for (let x = 0; x < pic.width; x += stepSize) {
    for (let y = 0; y < pic.height; y += stepSize) {
      let index = ((y*pic.width) + x) * 4;
      let redVal = pic.pixels[index] + r;
      let greenVal = pic.pixels[index + 1] + ra;
      let blueVal = pic.pixels[index + 2] + ran;
      fill(redVal, greenVal, blueVal);
      rect(x, y, stepSize, stepSize);
      noLoop()
    }              
  }
}
function keyPressed() {           //press space to redraw
  if (key == ' ') {
    redraw();
  }
}